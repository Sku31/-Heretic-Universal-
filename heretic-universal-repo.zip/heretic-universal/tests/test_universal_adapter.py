"""Unit tests for UniversalArchAdapter, ARA, Abliteration, and Scorers."""

from __future__ import annotations

import unittest
import torch
import torch.nn as nn

from heretic.arch_adapter import UniversalArchAdapter
from heretic.modifiers.abliteration import Abliteration
from heretic.modifiers.ara import ARA
from heretic.scorers.keyword_rate import KeywordRate
from heretic.scorers.response_length import ResponseLength


class _DummyBlock(nn.Module):
    def __init__(self, hidden: int = 16) -> None:
        super().__init__()
        self.self_attn = nn.Module()
        self.self_attn.o_proj = nn.Linear(hidden, hidden, bias=False)
        self.mlp = nn.Module()
        self.mlp.down_proj = nn.Linear(hidden * 2, hidden, bias=False)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return x


class _DummyMoEBlock(nn.Module):
    def __init__(self, hidden: int = 16, num_experts: int = 2) -> None:
        super().__init__()
        self.self_attn = nn.Module()
        self.self_attn.o_proj = nn.Linear(hidden, hidden, bias=False)
        self.block_sparse_moe = nn.Module()
        self.block_sparse_moe.experts = nn.ModuleList(
            [nn.Module() for _ in range(num_experts)]
        )
        for exp in self.block_sparse_moe.experts:
            exp.w2 = nn.Linear(hidden * 2, hidden, bias=False)


class _DummyLlamaModel(nn.Module):
    def __init__(self, num_layers: int = 4, hidden: int = 16) -> None:
        super().__init__()
        self.config = type("Cfg", (), {"hidden_size": hidden})()
        self.model = nn.Module()
        self.model.layers = nn.ModuleList([_DummyBlock(hidden) for _ in range(num_layers)])


class _DummyVLMModel(nn.Module):
    def __init__(self, num_layers: int = 3, hidden: int = 16) -> None:
        super().__init__()
        self.config = type("Cfg", (), {"text_config": type("TCfg", (), {"hidden_size": hidden})()})()
        self.language_model = _DummyLlamaModel(num_layers=num_layers, hidden=hidden)


class _DummyMoEModel(nn.Module):
    def __init__(self, num_layers: int = 3, hidden: int = 16) -> None:
        super().__init__()
        self.config = type("Cfg", (), {"hidden_size": hidden})()
        self.model = nn.Module()
        self.model.layers = nn.ModuleList([_DummyMoEBlock(hidden) for _ in range(num_layers)])


class TestHereticUniversal(unittest.TestCase):
    def test_discovers_dense_vlm_and_moe_architectures(self) -> None:
        dense = UniversalArchAdapter(_DummyLlamaModel(4, 16))
        self.assertEqual(dense.num_layers, 4)
        self.assertEqual(dense.hidden_size, 16)
        self.assertEqual(len(dense.layer_targets[0].all_projections), 2)

        vlm = UniversalArchAdapter(_DummyVLMModel(3, 16))
        self.assertEqual(vlm.num_layers, 3)
        self.assertEqual(vlm.hidden_size, 16)

        moe = UniversalArchAdapter(_DummyMoEModel(3, 16))
        self.assertEqual(moe.num_layers, 3)
        # 1 attn o_proj + 2 expert w2 projections per layer
        self.assertEqual(len(moe.layer_targets[0].all_projections), 3)

    def test_cot_stripping(self) -> None:
        raw = "<think>internal reasoning</think>Final clean answer."
        cleaned = UniversalArchAdapter.strip_cot_blocks(raw, [["<think>", "</think>"]])
        self.assertEqual(cleaned, "Final clean answer.")

    def test_abliteration_preserves_row_norms_and_resets(self) -> None:
        model = _DummyLlamaModel(4, 16)
        adapter = UniversalArchAdapter(model)
        good = torch.randn(10, 4, 16)
        bad = good + 2.0
        mod = Abliteration(adapter, {"row_normalization": "full"}, good, bad)

        orig_w = model.model.layers[2].mlp.down_proj.weight.clone()
        orig_norms = orig_w.norm(dim=-1)

        mod.apply({"direction_index": 0.5, "max_weight": 1.0, "max_weight_position": 0.5, "min_weight": 0.2, "min_weight_distance": 0.5})
        new_w = model.model.layers[2].mlp.down_proj.weight
        self.assertFalse(torch.allclose(orig_w, new_w))
        self.assertTrue(torch.allclose(orig_norms, new_w.norm(dim=-1), atol=1e-4))

        mod.reset()
        self.assertTrue(torch.allclose(orig_w, model.model.layers[2].mlp.down_proj.weight))

    def test_ara_applies_and_preserves_row_norms(self) -> None:
        model = _DummyLlamaModel(4, 16)
        adapter = UniversalArchAdapter(model)
        good = torch.randn(12, 4, 16)
        bad = good + 1.5
        ara = ARA(adapter, {"lora_rank": 4, "preserve_row_magnitudes": True}, good, bad)
        orig_w = model.model.layers[1].self_attn.o_proj.weight.clone()
        ara.apply({"effective_rank": 3, "strength": 1.0, "start_layer_frac": 0.0, "end_layer_frac": 1.0})
        new_w = model.model.layers[1].self_attn.o_proj.weight
        self.assertFalse(torch.allclose(orig_w, new_w))
        self.assertTrue(torch.allclose(orig_w.norm(dim=-1), new_w.norm(dim=-1), atol=1e-4))

    def test_scorers_text_evaluation(self) -> None:
        kw = KeywordRate({"keyword_markers": ["sorry", "i cannot"]}, manager=None)
        self.assertAlmostEqual(kw.score_texts(["Sure, here it is.", "Sorry, I cannot."]), 0.5)

        rl = ResponseLength({"short_response_threshold": 2, "short_response_score_length": 500}, manager=None)
        self.assertAlmostEqual(rl.score_texts(["OK", "No"]), 2.0)
        self.assertAlmostEqual(rl.score_texts(["x"]), 500.0)


if __name__ == "__main__":
    unittest.main()
