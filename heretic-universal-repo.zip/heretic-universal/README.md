# Heretic Universal — Training-Free LLM Modification

Universal-architecture implementation of the [Heretic](https://github.com/p-e-w/heretic) training-free model modification pipeline. Supports refusal suppression, slop reduction, sycophancy reduction, and response-length steering across **all major LLM architectures** without fine-tuning.

## Supported LLM Architectures

The built-in `UniversalArchAdapter` (`src/heretic/arch_adapter.py`) automatically discovers decoder blocks, attention output projections, MLP down-projections, and MoE expert layers across:

- **Dense Causal LMs**: Llama 2/3/4, Qwen 2/2.5/3, Mistral, Gemma 2/3, Phi-3/4, DeepSeek, Yi, Falcon, GPT-2, GPT-NeoX
- **Mixture-of-Experts (MoE)**: Mixtral, Qwen-MoE, DeepSeek-MoE (including shared + routed experts)
- **Multimodal / VLM Backbones**: Automatically unwraps `language_model.model` / `text_model`
- **Thinking / Reasoning Models**: Strips `<think>...</think>`, `[THINK]...[/THINK]`, and channel CoT blocks before scoring
- **Quantized Models**: Supports `none`, `bnb_4bit`, and `bnb_8bit` via `bitsandbytes` + LoRA export

## Quick Start

```bash
python -m venv .venv
source .venv/bin/activate
pip install -e ".[quantization]"

# Run with default refusal-suppression config on any Hugging Face model
heretic Qwen/Qwen3-4B-Instruct-2507

# Run non-interactively with custom config and LoRA export
heretic meta-llama/Llama-3.1-8B-Instruct --config config.default.toml --output-dir ./out_model --export-lora --non-interactive
```

## Configuration

See [`config.default.toml`](config.default.toml) for all options:
- **Modifiers**: `heretic.modifiers.ara.ARA` (Arbitrary-Rank Ablation, default) or `heretic.modifiers.abliteration.Abliteration` (Projected + Magnitude-Preserving Orthogonal Ablation).
- **Scorers**: `KeywordRate`, `KLDivergence`, `ResponseLength` (or custom plugins via `path/to/plugin.py:ClassName`).
- **Optimizer**: Optuna TPE hyperparameter search with checkpointing.

## License

AGPL-3.0-or-later (matching upstream [p-e-w/heretic](https://github.com/p-e-w/heretic)).
