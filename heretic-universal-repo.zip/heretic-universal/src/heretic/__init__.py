"""Heretic Universal: Training-free language model modification across all LLM architectures."""

__version__ = "2.1.0"
