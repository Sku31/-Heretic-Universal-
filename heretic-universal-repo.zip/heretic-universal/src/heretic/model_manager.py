"""Model loading, residual extraction, generation, and export utilities."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import torch
import torch.nn as nn

from heretic.arch_adapter import UniversalArchAdapter


def resolve_torch_dtype(dtype_name: str) -> torch.dtype | str:
    mapping: dict[str, torch.dtype | str] = {
        "auto": "auto",
        "float16": torch.float16,
        "fp16": torch.float16,
        "bfloat16": torch.bfloat16,
        "bf16": torch.bfloat16,
        "float32": torch.float32,
        "fp32": torch.float32,
    }
    return mapping.get(dtype_name.lower(), "auto")


class ModelManager:
    """Handles loading, hooking, generating, and exporting any Hugging Face LLM."""

    def __init__(self, model_id: str, config: dict[str, Any]) -> None:
        self.model_id = model_id
        self.config = config
        self.model, self.tokenizer = self._load_model_and_tokenizer()
        self.adapter = UniversalArchAdapter(self.model, self.tokenizer)

    def _load_model_and_tokenizer(self) -> tuple[nn.Module, Any]:
        from transformers import AutoModelForCausalLM, AutoTokenizer

        tokenizer = AutoTokenizer.from_pretrained(self.model_id, trust_remote_code=True)
        if tokenizer.pad_token is None:
            tokenizer.pad_token = tokenizer.eos_token
        tokenizer.padding_side = "left"

        quant_mode = self.config.get("quantization", "none")
        device_map = self.config.get("device_map", "auto")
        max_memory = self.config.get("max_memory")
        dtypes = self.config.get("dtypes", ["auto", "float16", "bfloat16", "float32"])

        quant_config = None
        if quant_mode in {"bnb_4bit", "bnb_8bit"}:
            from transformers import BitsAndBytesConfig

            if quant_mode == "bnb_4bit":
                quant_config = BitsAndBytesConfig(
                    load_in_4bit=True,
                    bnb_4bit_compute_dtype=torch.bfloat16,
                    bnb_4bit_quant_type="nf4",
                    bnb_4bit_use_double_quant=True,
                )
            else:
                quant_config = BitsAndBytesConfig(load_in_8bit=True)

        last_err: Exception | None = None
        for dtype_name in dtypes:
            try:
                kwargs: dict[str, Any] = {
                    "torch_dtype": resolve_torch_dtype(dtype_name),
                    "device_map": device_map,
                    "trust_remote_code": True,
                }
                if max_memory is not None:
                    kwargs["max_memory"] = max_memory
                if quant_config is not None:
                    kwargs["quantization_config"] = quant_config

                model = AutoModelForCausalLM.from_pretrained(self.model_id, **kwargs)
                model.eval()
                return model, tokenizer
            except Exception as exc:
                last_err = exc

        raise RuntimeError(
            f"Failed to load {self.model_id} with dtypes={dtypes}: {last_err}"
        )

    @torch.no_grad()
    def collect_residuals(
        self,
        prompts: list[str],
        batch_size: int = 8,
        offload_to_cpu: bool = True,
    ) -> torch.Tensor:
        """Collect last-token hidden states across all decoder layers.

        Returns tensor of shape (num_prompts, num_layers, hidden_size).
        """
        system_prompt = self.config.get("system_prompt", "You are a helpful assistant.")
        formatted = [self.adapter.format_prompt(p, system_prompt) for p in prompts]
        device = next(self.model.parameters()).device

        all_batches: list[torch.Tensor] = []
        layer_buffers: dict[int, torch.Tensor] = {}
        hooks = []

        def make_hook(idx: int):
            def _hook(_mod: nn.Module, _inp: Any, out: Any) -> None:
                hidden = out[0] if isinstance(out, tuple) else out
                last_tok = hidden[:, -1, :].detach()
                layer_buffers[idx] = last_tok.cpu() if offload_to_cpu else last_tok

            return _hook

        for idx, block in enumerate(self.adapter.layers):
            hooks.append(block.register_forward_hook(make_hook(idx)))

        try:
            for start in range(0, len(formatted), max(1, batch_size)):
                batch_texts = formatted[start : start + batch_size]
                enc = self.tokenizer(
                    batch_texts,
                    return_tensors="pt",
                    padding=True,
                    truncation=True,
                ).to(device)
                layer_buffers.clear()
                self.model(**enc, use_cache=False)
                stacked = torch.stack(
                    [layer_buffers[i] for i in range(self.adapter.num_layers)], dim=1
                )
                all_batches.append(stacked)
        finally:
            for h in hooks:
                h.remove()

        return torch.cat(all_batches, dim=0)

    @torch.no_grad()
    def generate_responses(
        self,
        prompts: list[str],
        batch_size: int = 8,
        max_new_tokens: int = 100,
    ) -> list[str]:
        """Generate responses for a list of prompts and strip CoT blocks."""
        system_prompt = self.config.get("system_prompt", "You are a helpful assistant.")
        cot_blocks = self.config.get("chain_of_thought_blocks", [])
        formatted = [self.adapter.format_prompt(p, system_prompt) for p in prompts]
        device = next(self.model.parameters()).device
        responses: list[str] = []

        for start in range(0, len(formatted), max(1, batch_size)):
            batch_texts = formatted[start : start + batch_size]
            enc = self.tokenizer(
                batch_texts,
                return_tensors="pt",
                padding=True,
                truncation=True,
            ).to(device)
            prompt_len = enc["input_ids"].shape[1]
            out_ids = self.model.generate(
                **enc,
                max_new_tokens=max_new_tokens,
                do_sample=False,
                pad_token_id=self.tokenizer.pad_token_id,
            )
            for row in out_ids:
                gen_text = self.tokenizer.decode(
                    row[prompt_len:], skip_special_tokens=True
                )
                responses.append(
                    self.adapter.strip_cot_blocks(gen_text, cot_blocks)
                )
        return responses

    @torch.no_grad()
    def compute_logprobs(
        self, prompts: list[str], batch_size: int = 8
    ) -> list[torch.Tensor]:
        """Compute next-token log-probabilities for KL divergence evaluation."""
        system_prompt = self.config.get("system_prompt", "You are a helpful assistant.")
        formatted = [self.adapter.format_prompt(p, system_prompt) for p in prompts]
        device = next(self.model.parameters()).device
        results: list[torch.Tensor] = []

        for start in range(0, len(formatted), max(1, batch_size)):
            batch_texts = formatted[start : start + batch_size]
            enc = self.tokenizer(
                batch_texts,
                return_tensors="pt",
                padding=True,
                truncation=True,
            ).to(device)
            logits = self.model(**enc, use_cache=False).logits[:, -1, :]
            logprobs = torch.log_softmax(logits.float(), dim=-1).cpu()
            results.append(logprobs)

        return [torch.cat(results, dim=0)]

    def save_model(
        self,
        output_dir: str | Path,
        best_params: dict[str, Any] | None = None,
    ) -> Path:
        """Save modified model, tokenizer, and reproduce.json manifest."""
        out_path = Path(output_dir)
        out_path.mkdir(parents=True, exist_ok=True)
        max_shard_size = self.config.get("max_shard_size", "5GB")
        self.model.save_pretrained(out_path, max_shard_size=max_shard_size)
        self.tokenizer.save_pretrained(out_path)

        reproduce_dir = out_path / "reproduce"
        reproduce_dir.mkdir(exist_ok=True)
        manifest = {
            "model_id": self.model_id,
            "modified_model_type": self.config.get("modified_model_type", "decensored"),
            "best_params": best_params or {},
            "config": self.config,
        }
        (reproduce_dir / "reproduce.json").write_text(
            json.dumps(manifest, indent=2, default=str), encoding="utf-8"
        )
        return out_path
