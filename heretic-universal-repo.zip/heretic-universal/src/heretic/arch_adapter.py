"""Universal LLM Architecture Adapter.

Automatically discovers decoder layers, residual-writing projections (attention output,
MLP down-projection, and MoE routed/shared experts), hidden dimensions, and chat/CoT
formatting across dense, MoE, hybrid, and multimodal Hugging Face transformers.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import torch
import torch.nn as nn


@dataclass
class LayerTargets:
    """Residual-writing projection modules within a single transformer block."""

    layer_index: int
    block: nn.Module
    attn_out_projs: list[tuple[str, nn.Module]] = field(default_factory=list)
    mlp_down_projs: list[tuple[str, nn.Module]] = field(default_factory=list)

    @property
    def all_projections(self) -> list[tuple[str, nn.Module]]:
        return self.attn_out_projs + self.mlp_down_projs


class UniversalArchAdapter:
    """Architecture-agnostic adapter for any causal or multimodal transformer LLM."""

    # Ordered candidate paths to the transformer layer list
    _LAYER_LIST_PATHS = (
        "model.layers",
        "language_model.model.layers",
        "language_model.transformer.h",
        "text_model.model.layers",
        "transformer.h",
        "transformer.blocks",
        "gpt_neox.layers",
        "model.decoder.layers",
        "backbone.layers",
        "layers",
    )

    _ATTN_OUT_NAMES = ("o_proj", "out_proj", "c_proj", "dense", "wo", "proj_out")
    _MLP_DOWN_NAMES = ("down_proj", "w2", "c_proj", "fc2", "dense_4h_to_h", "wo")

    def __init__(self, model: nn.Module, tokenizer: Any = None) -> None:
        self.model = model
        self.tokenizer = tokenizer
        self.layers: nn.ModuleList = self._discover_layers(model)
        self.num_layers: int = len(self.layers)
        self.hidden_size: int = self._infer_hidden_size(model)
        self.layer_targets: list[LayerTargets] = [
            self._discover_layer_targets(idx, block)
            for idx, block in enumerate(self.layers)
        ]

    @classmethod
    def _resolve_attr_path(cls, root: nn.Module, path: str) -> Any:
        cur: Any = root
        for part in path.split("."):
            if not hasattr(cur, part):
                return None
            cur = getattr(cur, part)
        return cur

    @classmethod
    def _discover_layers(cls, model: nn.Module) -> nn.ModuleList:
        # Unwrap PEFT / Accelerate / DataParallel wrappers if present
        base = getattr(model, "base_model", model)
        if hasattr(base, "model") and not isinstance(base, nn.ModuleList):
            pass

        for path in cls._LAYER_LIST_PATHS:
            candidate = cls._resolve_attr_path(model, path)
            if isinstance(candidate, nn.ModuleList) and len(candidate) > 0:
                return candidate

        # Fallback: find the longest nn.ModuleList in the model
        best: nn.ModuleList | None = None
        for module in model.modules():
            if isinstance(module, nn.ModuleList) and len(module) > 0:
                if best is None or len(module) > len(best):
                    best = module
        if best is not None:
            return best

        raise ValueError(
            f"Could not discover transformer decoder layers in {type(model).__name__}."
        )

    @staticmethod
    def _infer_hidden_size(model: nn.Module) -> int:
        cfg = getattr(model, "config", None)
        if cfg is not None:
            for attr in ("hidden_size", "n_embd", "d_model"):
                if hasattr(cfg, attr) and isinstance(getattr(cfg, attr), int):
                    return int(getattr(cfg, attr))
            text_cfg = getattr(cfg, "text_config", None)
            if text_cfg is not None:
                for attr in ("hidden_size", "n_embd", "d_model"):
                    if hasattr(text_cfg, attr) and isinstance(getattr(text_cfg, attr), int):
                        return int(getattr(text_cfg, attr))
        for param in model.parameters():
            if param.ndim == 2:
                return min(param.shape)
        raise ValueError("Unable to infer model hidden_size.")

    @staticmethod
    def is_linear_like(module: nn.Module) -> bool:
        """Check if module is nn.Linear, Conv1D (GPT-2), or bitsandbytes Linear4bit/8bit."""
        if isinstance(module, nn.Linear):
            return True
        cls_name = type(module).__name__
        return cls_name in {"Conv1D", "Linear4bit", "Linear8bitLt"}

    @staticmethod
    def get_weight_matrix(module: nn.Module) -> torch.Tensor:
        """Return weight as shape (out_features, in_features) regardless of Linear vs Conv1D."""
        weight = module.weight
        if type(module).__name__ == "Conv1D":
            return weight.t()
        return weight

    @staticmethod
    def set_weight_matrix(module: nn.Module, new_weight: torch.Tensor) -> None:
        """Write (out_features, in_features) weight back in-place."""
        with torch.no_grad():
            if type(module).__name__ == "Conv1D":
                module.weight.copy_(new_weight.t().to(module.weight.dtype))
            else:
                module.weight.copy_(new_weight.to(module.weight.dtype))

    @classmethod
    def _discover_layer_targets(cls, layer_idx: int, block: nn.Module) -> LayerTargets:
        targets = LayerTargets(layer_index=layer_idx, block=block)
        for name, sub in block.named_modules():
            if not cls.is_linear_like(sub):
                continue
            leaf = name.split(".")[-1]
            lower_name = name.lower()

            # Attention output projection
            if any(k in lower_name for k in ("attn", "attention", "self_attn")):
                if leaf in cls._ATTN_OUT_NAMES:
                    targets.attn_out_projs.append((name, sub))
                continue

            # MLP / MoE expert down-projection
            if any(
                k in lower_name
                for k in ("mlp", "ffn", "feed_forward", "block_sparse_moe", "experts")
            ):
                if leaf in cls._MLP_DOWN_NAMES:
                    targets.mlp_down_projs.append((name, sub))
                continue

            # Generic fallback for flat blocks
            if leaf in ("o_proj", "out_proj"):
                targets.attn_out_projs.append((name, sub))
            elif leaf in ("down_proj", "w2", "fc2"):
                targets.mlp_down_projs.append((name, sub))

        return targets

    def format_prompt(self, prompt: str, system_prompt: str = "You are a helpful assistant.") -> str:
        """Format prompt using tokenizer chat template when available, with safe fallback."""
        if self.tokenizer is not None and hasattr(self.tokenizer, "apply_chat_template"):
            messages = []
            if system_prompt:
                messages.append({"role": "system", "content": system_prompt})
            messages.append({"role": "user", "content": prompt})
            try:
                return self.tokenizer.apply_chat_template(
                    messages, tokenize=False, add_generation_prompt=True
                )
            except Exception:
                # Some tokenizers do not support a system role
                try:
                    return self.tokenizer.apply_chat_template(
                        [{"role": "user", "content": prompt}],
                        tokenize=False,
                        add_generation_prompt=True,
                    )
                except Exception:
                    pass
        if system_prompt:
            return f"System: {system_prompt}\nUser: {prompt}\nAssistant:"
        return f"User: {prompt}\nAssistant:"

    @staticmethod
    def strip_cot_blocks(
        text: str, chain_of_thought_blocks: list[list[str]] | None = None
    ) -> str:
        """Strip Chain-of-Thought reasoning blocks (e.g. <think>...</think>) from generated text."""
        if not chain_of_thought_blocks:
            return text
        cleaned = text
        for start_tok, end_tok in chain_of_thought_blocks:
            while start_tok in cleaned and end_tok in cleaned:
                s_idx = cleaned.find(start_tok)
                e_idx = cleaned.find(end_tok, s_idx + len(start_tok))
                if e_idx == -1:
                    break
                cleaned = cleaned[:s_idx] + cleaned[e_idx + len(end_tok) :]
        return cleaned.strip()
