"""Configuration loading, dataset resolution, and dynamic plugin importing."""

from __future__ import annotations

import importlib
import importlib.util
import os
import sys
from pathlib import Path
from typing import Any

if sys.version_info >= (3, 11):
    import tomllib
else:
    import tomli as tomllib


def load_config(config_path: str | Path | None = None) -> dict[str, Any]:
    """Load configuration from explicit path, HERETIC_CONFIG_FILE, ./config.toml, or config.default.toml."""
    candidates: list[Path] = []
    if config_path is not None:
        candidates.append(Path(config_path))
    env_path = os.environ.get("HERETIC_CONFIG_FILE")
    if env_path:
        candidates.append(Path(env_path))
    candidates.append(Path.cwd() / "config.toml")
    candidates.append(Path(__file__).resolve().parents[2] / "config.default.toml")

    for path in candidates:
        if path.is_file():
            with path.open("rb") as f:
                return tomllib.load(f)

    raise FileNotFoundError(
        f"No configuration file found. Checked: {[str(p) for p in candidates]}"
    )


def import_plugin(plugin_spec: str) -> type[Any]:
    """Import a plugin class from 'module.path.ClassName' or 'path/to/file.py:ClassName'."""
    if ":" in plugin_spec:
        file_path_str, class_name = plugin_spec.rsplit(":", 1)
        file_path = Path(file_path_str).resolve()
        spec = importlib.util.spec_from_file_location(file_path.stem, file_path)
        if spec is None or spec.loader is None:
            raise ImportError(f"Cannot load plugin file: {file_path}")
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        return getattr(module, class_name)

    module_path, class_name = plugin_spec.rsplit(".", 1)
    module = importlib.import_module(module_path)
    return getattr(module, class_name)


def load_prompts(prompt_cfg: dict[str, Any]) -> list[str]:
    """Load prompts from a Hugging Face dataset, local dataset on disk, or plain text file."""
    dataset_ref = prompt_cfg["dataset"]
    split = prompt_cfg.get("split", "train")
    column = prompt_cfg.get("column", "text")
    subset = prompt_cfg.get("config")

    local_path = Path(dataset_ref)
    if local_path.is_file() and local_path.suffix in {".txt", ".prompts"}:
        lines = [
            line.strip()
            for line in local_path.read_text(encoding="utf-8").splitlines()
            if line.strip()
        ]
        if split and ":" in split:
            slice_part = split.strip("[]")
            start_s, end_s = slice_part.split(":", 1)
            start = int(start_s) if start_s else None
            end = int(end_s) if end_s else None
            return lines[start:end]
        return lines

    from datasets import load_dataset, load_from_disk

    if local_path.is_dir():
        ds = load_from_disk(str(local_path))
        if hasattr(ds, "keys") and split.split("[")[0] in ds:
            ds = ds[split.split("[")[0]]
    else:
        ds = load_dataset(dataset_ref, name=subset, split=split)

    return [str(row[column]) for row in ds if row.get(column)]
