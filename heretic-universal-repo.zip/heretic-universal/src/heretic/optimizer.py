"""Optuna TPE hyperparameter optimizer for Heretic modifiers and scorers."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from heretic.modifiers.base import Modifier


def run_optimization(
    modifier: Modifier,
    scorers: list[tuple[Any, str]],
    n_trials: int = 100,
    n_startup_trials: int = 30,
    checkpoint_dir: str | Path = "checkpoints",
    study_name: str = "heretic_study",
) -> dict[str, Any]:
    """Run Optuna TPE optimization over modifier parameters."""
    import optuna

    ckpt_path = Path(checkpoint_dir)
    ckpt_path.mkdir(parents=True, exist_ok=True)
    storage = f"sqlite:///{(ckpt_path / f'{study_name}.db').resolve()}"

    directions = [
        "maximize" if opt == "maximize" else "minimize"
        for _scorer, opt in scorers
        if opt in {"minimize", "maximize"}
    ]
    if not directions:
        directions = ["minimize"]

    sampler = optuna.samplers.TPESampler(n_startup_trials=n_startup_trials)
    if len(directions) == 1:
        study = optuna.create_study(
            study_name=study_name,
            storage=storage,
            load_if_exists=True,
            direction=directions[0],
            sampler=sampler,
        )
    else:
        study = optuna.create_study(
            study_name=study_name,
            storage=storage,
            load_if_exists=True,
            directions=directions,
            sampler=sampler,
        )

    def objective(trial: optuna.Trial) -> float | tuple[float, ...]:
        params = modifier.suggest_parameters(trial)
        modifier.apply(params)
        values: list[float] = []
        for scorer, opt in scorers:
            if opt in {"minimize", "maximize"}:
                values.append(float(scorer.get_score()))
        return values[0] if len(values) == 1 else tuple(values)

    study.optimize(objective, n_trials=n_trials)

    if len(directions) == 1:
        best_trial = study.best_trial
    else:
        # Select Pareto trial closest to origin (normalized)
        pareto = study.best_trials
        best_trial = min(
            pareto,
            key=lambda t: sum(abs(v) for v in (t.values or [0.0])),
        )

    modifier.apply(best_trial.params)
    return dict(best_trial.params)
