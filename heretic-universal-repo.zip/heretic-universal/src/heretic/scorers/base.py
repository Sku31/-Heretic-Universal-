"""Abstract base class for Heretic scorer plugins."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any


class Scorer(ABC):
    """Base interface for all Heretic scorer plugins."""

    def __init__(self, settings: dict[str, Any], manager: Any) -> None:
        self.settings = settings
        self.manager = manager
        self.score_name: str = settings.get("score_name", type(self).__name__)

    @abstractmethod
    def get_score(self) -> float:
        """Compute scalar score on the currently loaded (possibly modified) model."""
