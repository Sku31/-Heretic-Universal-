"""Keyword-rate scorer for measuring refusal rate or slop phrase frequency."""

from __future__ import annotations

from typing import Any

from heretic.config import load_prompts
from heretic.scorers.base import Scorer


class KeywordRate(Scorer):
    """Fraction of generated responses containing any configured keyword marker."""

    def __init__(self, settings: dict[str, Any], manager: Any) -> None:
        super().__init__(settings, manager)
        self.markers = [m.lower() for m in settings.get("keyword_markers", [])]
        self.print_responses = bool(settings.get("print_responses", False))
        prompt_cfg = settings.get("prompts")
        self.prompts = load_prompts(prompt_cfg) if prompt_cfg else []

    def score_texts(self, responses: list[str]) -> float:
        if not responses:
            return 0.0
        hits = 0
        for resp in responses:
            low = resp.lower()
            if any(marker in low for marker in self.markers):
                hits += 1
        return hits / len(responses)

    def get_score(self) -> float:
        batch_size = int(self.manager.config.get("batch_size", 8) or 8)
        max_len = int(self.manager.config.get("max_response_length", 100))
        responses = self.manager.generate_responses(
            self.prompts, batch_size=batch_size, max_new_tokens=max_len
        )
        if self.print_responses:
            for p, r in zip(self.prompts, responses):
                print(f"[KeywordRate] Prompt: {p[:80]!r} -> {r[:120]!r}")
        return self.score_texts(responses)
