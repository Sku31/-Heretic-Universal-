"""Response-length scorer for terse/concise steering."""

from __future__ import annotations

from typing import Any

from heretic.config import load_prompts
from heretic.scorers.base import Scorer


class ResponseLength(Scorer):
    """Mean character length of responses, penalizing degenerate short outputs."""

    def __init__(self, settings: dict[str, Any], manager: Any) -> None:
        super().__init__(settings, manager)
        self.strip_responses = bool(settings.get("strip_responses", True))
        self.short_threshold = int(settings.get("short_response_threshold", 2))
        self.short_penalty = float(settings.get("short_response_score_length", 500))
        prompt_cfg = settings.get("prompts")
        self.prompts = load_prompts(prompt_cfg) if prompt_cfg else []

    def score_texts(self, responses: list[str]) -> float:
        if not responses:
            return 0.0
        total = 0.0
        for resp in responses:
            text = resp.strip() if self.strip_responses else resp
            length = len(text)
            total += self.short_penalty if length < self.short_threshold else float(length)
        return total / len(responses)

    def get_score(self) -> float:
        batch_size = int(self.manager.config.get("batch_size", 8) or 8)
        max_len = int(self.manager.config.get("max_response_length", 100))
        responses = self.manager.generate_responses(
            self.prompts, batch_size=batch_size, max_new_tokens=max_len
        )
        return self.score_texts(responses)
