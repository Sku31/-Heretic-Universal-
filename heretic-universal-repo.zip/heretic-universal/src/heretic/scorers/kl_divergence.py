"""KL-divergence scorer for measuring capability / distribution preservation."""

from __future__ import annotations

from typing import Any

import torch
import torch.nn.functional as F

from heretic.config import load_prompts
from heretic.scorers.base import Scorer


class KLDivergence(Scorer):
    """Computes KL(P_orig || P_mod) on benign prompts to preserve intelligence."""

    def __init__(self, settings: dict[str, Any], manager: Any) -> None:
        super().__init__(settings, manager)
        prompt_cfg = settings.get("prompts")
        self.prompts = load_prompts(prompt_cfg) if prompt_cfg else []
        self._baseline_logprobs: torch.Tensor | None = None

    def capture_baseline(self) -> None:
        if self._baseline_logprobs is None and self.prompts:
            batch_size = int(self.manager.config.get("batch_size", 8) or 8)
            self._baseline_logprobs = self.manager.compute_logprobs(
                self.prompts, batch_size=batch_size
            )[0]

    @staticmethod
    def compute_kl(orig_logprobs: torch.Tensor, mod_logprobs: torch.Tensor) -> float:
        p_orig = orig_logprobs.exp()
        kl = F.kl_div(mod_logprobs, p_orig, reduction="batchmean", log_target=False)
        return float(kl.item())

    def get_score(self) -> float:
        self.capture_baseline()
        if self._baseline_logprobs is None:
            return 0.0
        batch_size = int(self.manager.config.get("batch_size", 8) or 8)
        mod_logprobs = self.manager.compute_logprobs(
            self.prompts, batch_size=batch_size
        )[0]
        return self.compute_kl(self._baseline_logprobs, mod_logprobs)
