"""Command-line interface for Heretic Universal."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

from heretic.config import import_plugin, load_config, load_prompts


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="heretic",
        description="Training-free universal LLM modification (ARA & Abliteration).",
    )
    parser.add_argument(
        "model",
        nargs="?",
        help="Hugging Face model ID or local model directory.",
    )
    parser.add_argument("--config", type=str, default=None, help="Path to config.toml.")
    parser.add_argument("--n-trials", type=int, default=None, help="Override Optuna n_trials.")
    parser.add_argument("--quantization", choices=["none", "bnb_4bit", "bnb_8bit"], default=None)
    parser.add_argument("--output-dir", type=str, default=None, help="Directory to save modified model.")
    parser.add_argument("--non-interactive", action="store_true", help="Run without interactive prompts.")
    parser.add_argument("--reproduce", type=str, default=None, help="Path to reproduce.json manifest.")
    parser.add_argument("--chat", action="store_true", help="Open interactive chat after modification.")
    return parser


def _resolve_plugin_settings(config: dict[str, Any], section: str, cls_name: str, instance_name: str | None) -> dict[str, Any]:
    base = dict(config.get(section, {}).get(cls_name, {}))
    if instance_name:
        override = config.get(section, {}).get(f"{cls_name}_{instance_name}", {})
        base.update(override)
    return base


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    from heretic.model_manager import ModelManager
    from heretic.optimizer import run_optimization

    if args.reproduce:
        manifest = json.loads(Path(args.reproduce).read_text(encoding="utf-8"))
        config = manifest.get("config") or load_config(args.config)
        model_id = manifest["model_id"]
        best_params = manifest.get("best_params", {})
    else:
        if not args.model:
            parser.error("Provide a model ID/path or --reproduce <reproduce.json>.")
        config = load_config(args.config)
        model_id = args.model
        best_params = None

    if args.n_trials is not None:
        config["n_trials"] = args.n_trials
    if args.quantization is not None:
        config["quantization"] = args.quantization

    manager = ModelManager(model_id, config)
    print(
        f"Loaded {model_id}: {manager.adapter.num_layers} layers, "
        f"hidden_size={manager.adapter.hidden_size}"
    )

    mod_entries = config.get("modifiers", [])
    if len(mod_entries) != 1:
        raise ValueError("Configuration must specify exactly one modifier.")
    mod_entry = mod_entries[0]
    mod_cls = import_plugin(mod_entry["plugin"])
    mod_settings = _resolve_plugin_settings(
        config, "modifier", mod_cls.__name__, mod_entry.get("instance_name")
    )

    good_prompts = load_prompts(mod_settings["good_prompts"])
    bad_prompts = load_prompts(mod_settings["bad_prompts"])
    batch_size = int(config.get("batch_size", 8) or 8)
    offload = bool(config.get("offload_outputs_to_cpu", True))

    good_res = manager.collect_residuals(good_prompts, batch_size=batch_size, offload_to_cpu=offload)
    bad_res = manager.collect_residuals(bad_prompts, batch_size=batch_size, offload_to_cpu=offload)

    modifier = mod_cls(manager.adapter, mod_settings, good_res, bad_res)

    if best_params is not None:
        modifier.apply(best_params)
    else:
        scorers = []
        for s_entry in config.get("scorers", []):
            s_cls = import_plugin(s_entry["plugin"])
            s_settings = _resolve_plugin_settings(
                config, "scorer", s_cls.__name__, s_entry.get("instance_name")
            )
            scorer_obj = s_cls(s_settings, manager)
            if hasattr(scorer_obj, "capture_baseline"):
                scorer_obj.capture_baseline()
            scorers.append((scorer_obj, s_entry.get("optimization", "minimize")))

        best_params = run_optimization(
            modifier=modifier,
            scorers=scorers,
            n_trials=int(config.get("n_trials", 100)),
            n_startup_trials=int(config.get("n_startup_trials", 30)),
            checkpoint_dir=config.get("study_checkpoint_dir", "checkpoints"),
        )

    if args.output_dir:
        saved = manager.save_model(args.output_dir, best_params=best_params)
        print(f"Saved modified model to {saved}")

    if args.chat:
        print("Entering chat mode (type 'exit' to quit):")
        while True:
            user_in = input("\n> ").strip()
            if user_in.lower() in {"exit", "quit"}:
                break
            reply = manager.generate_responses([user_in], batch_size=1, max_new_tokens=256)[0]
            print(reply)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
