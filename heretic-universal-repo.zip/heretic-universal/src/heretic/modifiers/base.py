"""Abstract base class for Heretic modifier plugins."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from heretic.arch_adapter import UniversalArchAdapter


class Modifier(ABC):
    """Interface for all pluggable weight/activation modifiers."""

    def __init__(self, adapter: UniversalArchAdapter, settings: dict[str, Any]) -> None:
        self.adapter = adapter
        self.settings = settings
        self._original_weights: dict[str, Any] = {}

    @abstractmethod
    def suggest_parameters(self, trial: Any) -> dict[str, Any]:
        """Suggest hyperparameters for an Optuna trial."""

    @abstractmethod
    def apply(self, params: dict[str, Any]) -> None:
        """Apply weight modifications in-place for the given trial parameters."""

    def snapshot_weights(self) -> None:
        """Store original weights on CPU so trials can be cleanly reset."""
        if self._original_weights:
            return
        for lt in self.adapter.layer_targets:
            for name, mod in lt.all_projections:
                key = f"L{lt.layer_index}.{name}"
                self._original_weights[key] = (
                    self.adapter.get_weight_matrix(mod).detach().cpu().clone()
                )

    def reset(self) -> None:
        """Restore original unmodified weights."""
        if not self._original_weights:
            return
        for lt in self.adapter.layer_targets:
            for name, mod in lt.all_projections:
                key = f"L{lt.layer_index}.{name}"
                if key in self._original_weights:
                    orig = self._original_weights[key].to(mod.weight.device)
                    self.adapter.set_weight_matrix(mod, orig)
