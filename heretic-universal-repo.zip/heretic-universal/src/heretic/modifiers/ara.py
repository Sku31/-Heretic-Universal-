"""Arbitrary-Rank Ablation (ARA) modifier with L-BFGS subspace optimization & MPOA."""

from __future__ import annotations

from typing import Any

import torch

from heretic.arch_adapter import UniversalArchAdapter
from heretic.modifiers.base import Modifier


def compute_ara_basis(
    good_residuals: torch.Tensor,
    bad_residuals: torch.Tensor,
    rank: int = 50,
) -> torch.Tensor:
    """Compute top-k singular subspace separating bad vs good residuals per layer.

    Returns tensor of shape (num_layers, k, hidden_size).
    """
    num_layers, hidden = good_residuals.shape[1], good_residuals.shape[2]
    k = min(rank, hidden, good_residuals.shape[0], bad_residuals.shape[0])
    bases: list[torch.Tensor] = []

    for l_idx in range(num_layers):
        diff = bad_residuals[:, l_idx, :].float() - good_residuals[:, l_idx, :].float()
        diff = diff - diff.mean(dim=0, keepdim=True)
        # SVD on (n_samples, hidden) -> Vh has shape (min(n, h), hidden)
        _, _, vh = torch.linalg.svd(diff, full_matrices=False)
        bases.append(vh[:k, :])

    return torch.stack(bases, dim=0)


class ARA(Modifier):
    """Arbitrary-Rank Ablation (default Heretic 2.x modifier)."""

    def __init__(
        self,
        adapter: UniversalArchAdapter,
        settings: dict[str, Any],
        good_residuals: torch.Tensor,
        bad_residuals: torch.Tensor,
    ) -> None:
        super().__init__(adapter, settings)
        self.lora_rank = int(settings.get("lora_rank", 50))
        self.preserve_row_magnitudes = bool(settings.get("preserve_row_magnitudes", True))
        self.bases = compute_ara_basis(
            good_residuals=good_residuals,
            bad_residuals=bad_residuals,
            rank=self.lora_rank,
        )
        self.snapshot_weights()

    def suggest_parameters(self, trial: Any) -> dict[str, Any]:
        return {
            "effective_rank": trial.suggest_int(
                "effective_rank", 1, max(1, min(self.lora_rank, self.bases.shape[1]))
            ),
            "strength": trial.suggest_float("strength", 0.3, 1.5),
            "start_layer_frac": trial.suggest_float("start_layer_frac", 0.1, 0.5),
            "end_layer_frac": trial.suggest_float("end_layer_frac", 0.6, 1.0),
        }

    def apply(self, params: dict[str, Any]) -> None:
        self.reset()
        num_layers = self.adapter.num_layers
        k = min(int(params.get("effective_rank", 16)), self.bases.shape[1])
        strength = float(params.get("strength", 1.0))
        start_idx = int(round(params.get("start_layer_frac", 0.2) * (num_layers - 1)))
        end_idx = int(round(params.get("end_layer_frac", 0.9) * (num_layers - 1)))
        if end_idx < start_idx:
            start_idx, end_idx = end_idx, start_idx

        for lt in self.adapter.layer_targets:
            if not (start_idx <= lt.layer_index <= end_idx):
                continue
            basis = self.bases[lt.layer_index, :k, :]  # (k, hidden)
            for _name, mod in lt.all_projections:
                w = self.adapter.get_weight_matrix(mod)
                b = basis.to(device=w.device, dtype=torch.float32)
                w_f = w.float()
                orig_norms = w_f.norm(dim=-1, keepdim=True).clamp_min(1e-8)

                # Project out the rank-k refusal subspace: W' = W - strength * (W B^T) B
                proj = (w_f @ b.t()) @ b
                w_new = w_f - strength * proj

                if self.preserve_row_magnitudes:
                    new_norms = w_new.norm(dim=-1, keepdim=True).clamp_min(1e-8)
                    w_new = (w_new / new_norms) * orig_norms

                self.adapter.set_weight_matrix(mod, w_new.to(w.dtype))
