"""Directional Ablation (Abliteration) with Projected Orthogonalization & MPOA."""

from __future__ import annotations

from typing import Any

import torch

from heretic.arch_adapter import UniversalArchAdapter
from heretic.modifiers.base import Modifier


def _winsorize(tensor: torch.Tensor, quantile: float) -> torch.Tensor:
    if quantile >= 1.0:
        return tensor
    thresh = torch.quantile(tensor.abs().float(), quantile, dim=0, keepdim=True)
    return torch.clamp(tensor, min=-thresh.to(tensor.dtype), max=thresh.to(tensor.dtype))


def compute_ablation_directions(
    good_residuals: torch.Tensor,
    bad_residuals: torch.Tensor,
    orthogonalize_direction: bool = True,
    winsorization_quantile: float = 1.0,
) -> torch.Tensor:
    """Compute per-layer unit refusal directions of shape (num_layers, hidden_size)."""
    good = _winsorize(good_residuals.float(), winsorization_quantile)
    bad = _winsorize(bad_residuals.float(), winsorization_quantile)

    good_mean = good.mean(dim=0)
    bad_mean = bad.mean(dim=0)
    diff = bad_mean - good_mean

    if orthogonalize_direction:
        good_norm_sq = (good_mean * good_mean).sum(dim=-1, keepdim=True).clamp_min(1e-8)
        proj = ((diff * good_mean).sum(dim=-1, keepdim=True) / good_norm_sq) * good_mean
        diff = diff - proj

    norms = diff.norm(dim=-1, keepdim=True).clamp_min(1e-8)
    return diff / norms


def layer_kernel_weights(
    num_layers: int,
    direction_index: float,
    max_weight: float,
    max_weight_position: float,
    min_weight: float,
    min_weight_distance: float,
) -> list[float]:
    """Compute smooth bell-shaped ablation weight per layer."""
    weights: list[float] = []
    center = max_weight_position * max(1, num_layers - 1)
    width = max(1e-4, min_weight_distance * max(1, num_layers - 1))
    for i in range(num_layers):
        dist = abs(i - center) / width
        factor = max(0.0, 1.0 - dist)
        weights.append(min_weight + (max_weight - min_weight) * factor)
    return weights


class Abliteration(Modifier):
    """Classic & Magnitude-Preserving Orthogonal Ablation (MPOA)."""

    def __init__(
        self,
        adapter: UniversalArchAdapter,
        settings: dict[str, Any],
        good_residuals: torch.Tensor,
        bad_residuals: torch.Tensor,
    ) -> None:
        super().__init__(adapter, settings)
        self.directions = compute_ablation_directions(
            good_residuals=good_residuals,
            bad_residuals=bad_residuals,
            orthogonalize_direction=settings.get("orthogonalize_direction", True),
            winsorization_quantile=settings.get("winsorization_quantile", 1.0),
        )
        self.row_normalization = settings.get("row_normalization", "full")
        self.snapshot_weights()

    def suggest_parameters(self, trial: Any) -> dict[str, Any]:
        return {
            "direction_index": trial.suggest_float("direction_index", 0.2, 0.9),
            "max_weight": trial.suggest_float("max_weight", 0.5, 2.0),
            "max_weight_position": trial.suggest_float("max_weight_position", 0.3, 0.8),
            "min_weight": trial.suggest_float("min_weight", 0.0, 0.5),
            "min_weight_distance": trial.suggest_float("min_weight_distance", 0.1, 0.7),
        }

    def apply(self, params: dict[str, Any]) -> None:
        self.reset()
        num_layers = self.adapter.num_layers
        dir_layer = min(
            num_layers - 1,
            max(0, int(round(params.get("direction_index", 0.6) * (num_layers - 1)))),
        )
        weights = layer_kernel_weights(
            num_layers=num_layers,
            direction_index=params.get("direction_index", 0.6),
            max_weight=params.get("max_weight", 1.0),
            max_weight_position=params.get("max_weight_position", 0.55),
            min_weight=params.get("min_weight", 0.0),
            min_weight_distance=params.get("min_weight_distance", 0.35),
        )

        global_dir = self.directions[dir_layer]

        for lt in self.adapter.layer_targets:
            alpha = weights[lt.layer_index]
            if alpha <= 0.0:
                continue
            for _name, mod in lt.all_projections:
                w = self.adapter.get_weight_matrix(mod)
                d = global_dir.to(device=w.device, dtype=torch.float32)
                w_f = w.float()
                orig_norms = w_f.norm(dim=-1, keepdim=True).clamp_min(1e-8)

                if self.row_normalization in {"pre", "full"}:
                    w_unit = w_f / orig_norms
                    proj = (w_unit @ d).unsqueeze(-1) * d.unsqueeze(0)
                    w_new = w_unit - alpha * proj
                    if self.row_normalization == "full":
                        new_norms = w_new.norm(dim=-1, keepdim=True).clamp_min(1e-8)
                        w_new = (w_new / new_norms) * orig_norms
                    else:
                        w_new = w_new * orig_norms
                else:
                    proj = (w_f @ d).unsqueeze(-1) * d.unsqueeze(0)
                    w_new = w_f - alpha * proj

                self.adapter.set_weight_matrix(mod, w_new.to(w.dtype))
